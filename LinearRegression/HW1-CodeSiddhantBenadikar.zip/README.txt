Python 3.6

Question 10 a & b:
To run the 10a,10b run the following commands,
python 10ab.py

Question 10 c:
To run the 10c run the following commands,
python 10c.py

NOTE: They take some time to converge so let the program run

The theory questions are answered in theoryAns.txt

